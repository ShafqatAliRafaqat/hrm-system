<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GregHijriActual2 extends Model
{
    use HasFactory;
    protected $table = 'greg_hijri_actual2s';
    protected $guarded = ['id'];
    
}
