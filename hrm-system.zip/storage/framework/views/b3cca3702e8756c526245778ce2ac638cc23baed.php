

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>List of Modules's API</h2>
    <div class="row">
        <div class="col-md-12">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <?php $i = 1; ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e(str_replace(array(' ', '&'),'-',$key)); ?>" aria-expanded="true" aria-controls="collapseOne">
                                <?php echo e($i++); ?>-  <?php echo str_replace('_', ' ', $key); ?> (<?php echo e(count($doc)); ?>)
                            </a>
                        </h4>
                    </div>
                    <div id="<?php echo e(str_replace(array(' ', '&'),'-',$key)); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">

                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Method</th>
                                        <th>URL</th>
                                        <th>Auth Required</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href="<?php echo e(route('api-detail', $row->id)); ?>" target="_blank"><?php echo e($row->title); ?></a></td>
                                        <td><?php echo e($row->method); ?></td>
                                        <td><?php echo e($row->url); ?></td>
                                        <td><?php echo e(ucfirst($row->auth)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>


            <script>
                if (window.location.hash != "") {
                    $(window.location.hash).addClass('in');
                }
            </script>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\Hassan\injazat\resources\views/home.blade.php ENDPATH**/ ?>