<?php

use App\Http\Libraries\ResponseBuilder;

function responseBuilder(){
        $responseBuilder = new ResponseBuilder();
        return $responseBuilder;
    }