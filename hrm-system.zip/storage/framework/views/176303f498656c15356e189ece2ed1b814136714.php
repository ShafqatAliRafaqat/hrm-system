<div class="col-sm-12">
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
	<!--<button type="button" class="close" data-dismiss="alert">×</button>-->	
        <strong><?php echo e($message); ?></strong>
</div>
<?php  session()->forget('success') ?>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block">
	<!--<button type="button" class="close" data-dismiss="alert">×</button>-->	
        <strong><?php echo e($message); ?></strong>
</div>
<?php  session()->forget('error') ?>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block">
	<!--<button type="button" class="close" data-dismiss="alert">×</button>-->	
	<strong><?php echo e($message); ?></strong>
</div>
<?php  session()->forget('warning') ?>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block">
	<!--<button type="button" class="close" data-dismiss="alert">×</button>-->	
	<strong><?php echo e($message); ?></strong>
</div>
<?php  session()->forget('info') ?>
<?php endif; ?>


<?php if($errors->any()): ?>
<div class="alert alert-danger">
	<!--<button type="button" class="close" data-dismiss="alert">×</button>-->	
	Please check the form below for errors
</div>
<?php endif; ?>
</div><?php /**PATH E:\Xampp\htdocs\Hassan\hrm-system\resources\views/flash-message.blade.php ENDPATH**/ ?>